import Link from "next/link"

interface LogoProps {
  className?: string
  textColor?: string
  size?: "small" | "medium" | "large"
}

export function Logo({ className = "", textColor = "white", size = "medium" }: LogoProps) {
  // กำหนดขนาดตามพารามิเตอร์ size
  const logoSizes = {
    small: {
      width: 120,
      height: 40,
      fontSize: "text-lg",
    },
    medium: {
      width: 150,
      height: 50,
      fontSize: "text-xl",
    },
    large: {
      width: 210,
      height: 70,
      fontSize: "text-2xl",
    },
  }

  const { width, height, fontSize } = logoSizes[size]

  return (
    <Link href="/" className={`flex items-center ${className}`}>
      <div className="relative">
        <svg
          width={width}
          height={height}
          viewBox="0 0 210 70"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="overflow-visible"
        >
          {/* รวงข้าวด้านซ้าย */}
          <g className="rice-stalk-left">
            <path
              d="M30 35C30 35 25 25 28 15C31 5 40 10 38 20C36 30 30 35 30 35Z"
              fill="#ebba4d"
              stroke="#d9a93c"
              strokeWidth="1.5"
            />
            <path
              d="M22 18C22 18 25 15 28 18C31 21 28 25 28 25"
              stroke="#d9a93c"
              strokeWidth="1.5"
              strokeLinecap="round"
            />
            <path
              d="M25 12C25 12 28 9 31 12C34 15 31 19 31 19"
              stroke="#d9a93c"
              strokeWidth="1.5"
              strokeLinecap="round"
            />
            <path d="M32 8C32 8 35 5 38 8C41 11 38 15 38 15" stroke="#d9a93c" strokeWidth="1.5" strokeLinecap="round" />
            <circle cx="28" cy="18" r="2" fill="#f5d78e" />
            <circle cx="31" cy="12" r="2" fill="#f5d78e" />
            <circle cx="38" cy="8" r="2" fill="#f5d78e" />
          </g>

          {/* รวงข้าวด้านขวา */}
          <g className="rice-stalk-right">
            <path
              d="M180 35C180 35 185 25 182 15C179 5 170 10 172 20C174 30 180 35 180 35Z"
              fill="#ebba4d"
              stroke="#d9a93c"
              strokeWidth="1.5"
            />
            <path
              d="M188 18C188 18 185 15 182 18C179 21 182 25 182 25"
              stroke="#d9a93c"
              strokeWidth="1.5"
              strokeLinecap="round"
            />
            <path
              d="M185 12C185 12 182 9 179 12C176 15 179 19 179 19"
              stroke="#d9a93c"
              strokeWidth="1.5"
              strokeLinecap="round"
            />
            <path
              d="M178 8C178 8 175 5 172 8C169 11 172 15 172 15"
              stroke="#d9a93c"
              strokeWidth="1.5"
              strokeLinecap="round"
            />
            <circle cx="182" cy="18" r="2" fill="#f5d78e" />
            <circle cx="179" cy="12" r="2" fill="#f5d78e" />
            <circle cx="172" cy="8" r="2" fill="#f5d78e" />
          </g>

          {/* พื้นหลังชื่อร้าน */}
          <rect x="40" y="15" width="130" height="40" rx="20" fill="#ebba4d" />

          {/* เส้นขอบด้านล่าง */}
          <path
            d="M40 45C40 45 60 55 105 55C150 55 170 45 170 45"
            stroke="#d9a93c"
            strokeWidth="2"
            strokeLinecap="round"
          />

          {/* จุดเม็ดข้าว */}
          <circle cx="55" cy="30" r="3" fill="#f5d78e" />
          <circle cx="155" cy="30" r="3" fill="#f5d78e" />
        </svg>

        {/* ข้อความชื่อร้าน */}
        <div
          className={`absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 ${fontSize} font-serif font-bold tracking-wide text-${textColor}`}
          style={{ textShadow: "1px 1px 2px rgba(0,0,0,0.1)" }}
        >
          ปู่กะย่า
        </div>
      </div>
    </Link>
  )
}
