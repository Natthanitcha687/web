"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X, ShoppingCart, User, LogOut } from "lucide-react"
import { useAuth } from "@/contexts/auth-context"
import { Button } from "@/components/ui/button"
import { Logo } from "@/components/logo"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

export function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const { user, logout } = useAuth()

  return (
    <header className="bg-[#ebba4d] sticky top-0 z-50 shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <Logo size="medium" textColor="white" />

          {/* Desktop Navigation and User Icons */}
          <div className="hidden md:flex items-center space-x-6">
            <nav className="flex space-x-8 mr-4">
              <Link
                href="/"
                className="text-white hover:text-[#eee4c9] font-medium transition duration-300 tracking-wide"
              >
                หน้าแรก
              </Link>
              <Link
                href="/products"
                className="text-white hover:text-[#eee4c9] font-medium transition duration-300 tracking-wide"
              >
                สินค้าของเรา
              </Link>
              <Link
                href="/how-to-order"
                className="text-white hover:text-[#eee4c9] font-medium transition duration-300 tracking-wide"
              >
                วิธีการสั่งซื้อ
              </Link>
              <Link
                href="/contact"
                className="text-white hover:text-[#eee4c9] font-medium transition duration-300 tracking-wide"
              >
                ช่องทางติดต่อ
              </Link>
            </nav>

            {/* User and Cart Icons */}
            <div className="flex items-center space-x-4">
              {user ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="text-white hover:bg-[#d9a93c] rounded-full p-2">
                      <User className="h-6 w-6" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56 font-sans">
                    <div className="px-4 py-3 border-b">
                      <p className="text-sm font-medium">สวัสดี, {user.name}</p>
                      <p className="text-xs text-gray-500 truncate">{user.email}</p>
                    </div>
                    <DropdownMenuItem asChild>
                      <Link href="/profile">โปรไฟล์ของฉัน</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/orders">ประวัติการสั่งซื้อ</Link>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={logout} className="text-red-500">
                      <LogOut className="mr-2 h-4 w-4" />
                      <span>ออกจากระบบ</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Link href="/login">
                  <Button variant="ghost" className="text-white hover:bg-[#d9a93c] rounded-full p-2">
                    <User className="h-6 w-6" />
                  </Button>
                </Link>
              )}

              <Link href="/cart" className="text-white p-2 rounded-full hover:bg-[#d9a93c] transition duration-300">
                <ShoppingCart className="h-6 w-6" />
              </Link>
            </div>
          </div>

          {/* Mobile Menu Button */}
          <button className="text-white md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden bg-[#ebba4d] pb-4">
          <nav className="flex flex-col space-y-4 px-4">
            <Link
              href="/"
              className="text-white hover:text-[#eee4c9] font-medium transition duration-300 py-2 tracking-wide"
              onClick={() => setIsMenuOpen(false)}
            >
              หน้าแรก
            </Link>
            <Link
              href="/products"
              className="text-white hover:text-[#eee4c9] font-medium transition duration-300 py-2 tracking-wide"
              onClick={() => setIsMenuOpen(false)}
            >
              สินค้าของเรา
            </Link>
            <Link
              href="/how-to-order"
              className="text-white hover:text-[#eee4c9] font-medium transition duration-300 py-2 tracking-wide"
              onClick={() => setIsMenuOpen(false)}
            >
              วิธีการสั่งซื้อ
            </Link>
            <Link
              href="/contact"
              className="text-white hover:text-[#eee4c9] font-medium transition duration-300 py-2 tracking-wide"
              onClick={() => setIsMenuOpen(false)}
            >
              ช่องทางติดต่อ
            </Link>
            {!user && (
              <>
                <Link
                  href="/login"
                  className="text-white hover:text-[#eee4c9] font-medium transition duration-300 py-2 tracking-wide"
                  onClick={() => setIsMenuOpen(false)}
                >
                  เข้าสู่ระบบ
                </Link>
                <Link
                  href="/register"
                  className="text-white hover:text-[#eee4c9] font-medium transition duration-300 py-2 tracking-wide"
                  onClick={() => setIsMenuOpen(false)}
                >
                  สมัครสมาชิก
                </Link>
              </>
            )}
            {user && (
              <>
                <Link
                  href="/profile"
                  className="text-white hover:text-[#eee4c9] font-medium transition duration-300 py-2 tracking-wide"
                  onClick={() => setIsMenuOpen(false)}
                >
                  โปรไฟล์ของฉัน
                </Link>
                <Link
                  href="/orders"
                  className="text-white hover:text-[#eee4c9] font-medium transition duration-300 py-2 tracking-wide"
                  onClick={() => setIsMenuOpen(false)}
                >
                  ประวัติการสั่งซื้อ
                </Link>
                <button
                  className="text-white hover:text-[#eee4c9] font-medium transition duration-300 py-2 text-left tracking-wide"
                  onClick={() => {
                    logout()
                    setIsMenuOpen(false)
                  }}
                >
                  ออกจากระบบ
                </button>
              </>
            )}
          </nav>
        </div>
      )}
    </header>
  )
}
