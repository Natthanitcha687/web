"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function OrdersPage() {
  const { user, isLoading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/login")
    }
  }, [user, isLoading, router])

  if (isLoading || !user) {
    return (
      <main className="min-h-screen bg-[#eee4c9] py-16">
        <div className="container mx-auto px-4">
          <div className="text-center">กำลังโหลด...</div>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-[#eee4c9] py-16">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold text-center mb-12 text-[#ebba4d]">ประวัติการสั่งซื้อ</h1>

        <div className="max-w-4xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl text-[#ebba4d]">ประวัติการสั่งซื้อทั้งหมด</CardTitle>
              <CardDescription>รายการสั่งซื้อทั้งหมดของคุณ</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8 text-gray-500">
                <p>คุณยังไม่มีประวัติการสั่งซื้อ</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </main>
  )
}
