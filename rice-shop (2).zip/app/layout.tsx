import type React from "react"
import "./globals.css"
import type { Metadata } from "next"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { AuthProvider } from "@/contexts/auth-context"
import { Toaster } from "@/components/ui/toaster"
import { Sarabun, Playfair_Display } from "next/font/google"

// ฟอนต์ Sarabun สำหรับเนื้อหาทั่วไป - ฟอนต์ไทยที่อ่านง่ายและดูทันสมัย
const sarabun = Sarabun({
  subsets: ["thai", "latin"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-sarabun",
  display: "swap",
})

// ฟอนต์ Playfair Display สำหรับหัวข้อ - ฟอนต์ที่ดูหรูหราและมีสไตล์
const playfair = Playfair_Display({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-playfair",
  display: "swap",
})

export const metadata: Metadata = {
  title: "ร้านข้าวปู่กะย่า - ข้าวคุณภาพดี",
  description: "ร้านข้าวปู่กะย่า จำหน่ายข้าวหอมมะลิ ข้าวกล้อง ข้าวไรซ์เบอร์รี่ และกล้วยตากคุณภาพดี",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="th" className={`${sarabun.variable} ${playfair.variable}`}>
      <body className={sarabun.className}>
        <AuthProvider>
          <Navbar />
          {children}
          <Footer />
          <Toaster />
        </AuthProvider>
      </body>
    </html>
  )
}
