import Image from "next/image"
import Link from "next/link"
import { ShoppingCart, Phone, Mail, MapPin } from "lucide-react"
import { Logo } from "@/components/logo"

export default function Home() {
  return (
    <main className="min-h-screen bg-[#eee4c9]">
      {/* Hero Section */}
      <section className="relative h-[500px] w-full">
        <div className="absolute inset-0 bg-black/40 z-10" />
        <Image src="/images/rice-hero.jpg" alt="ข้าวคุณภาพดีจากร้านปู่กะย่า" fill priority className="object-cover" />
        <div className="relative z-20 container mx-auto px-4 h-full flex flex-col justify-center items-center text-center">
          <div className="mb-6">
            <Logo size="large" textColor="white" />
          </div>
          <h1 className="text-4xl md:text-6xl font-serif font-bold text-white mb-4 tracking-wide text-shadow-elegant">
            ข้าวคุณภาพดี จากร้าน "ปู่กะย่า"
          </h1>
          <p className="text-xl text-white mb-8 tracking-wide max-w-2xl">
            ข้าวหอมมะลิ ข้าวกล้อง ข้าวไรซ์เบอร์รี่ และกล้วยตาก คัดสรรจากแหล่งผลิตชั้นดี เพื่อคุณภาพที่คู่ควรกับทุกมื้ออาหาร
          </p>
          <Link
            href="/products"
            className="bg-[#ebba4d] hover:bg-[#d9a93c] text-white font-bold py-3 px-8 rounded-full transition duration-300 tracking-wide shadow-md"
          >
            ดูสินค้าทั้งหมด
          </Link>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-serif font-bold text-center mb-12 text-[#ebba4d] tracking-wide">สินค้าแนะนำ</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Product 1 */}
            <div className="bg-[#eee4c9] rounded-lg overflow-hidden shadow-lg transition-transform duration-300 hover:transform hover:scale-105 elegant-card">
              <div className="relative h-64">
                <Image src="/images/jasmine-rice.jpg" alt="ข้าวหอมมะลิ" fill className="object-cover" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-serif font-bold mb-2 tracking-wide">ข้าวหอมมะลิ</h3>
                <p className="text-gray-700 mb-4 text-elegant">ข้าวหอมมะลิคุณภาพดี หอมนุ่ม รสชาติดีเยี่ยม</p>
                <div className="flex justify-between items-center">
                  <span className="text-xl font-bold text-[#ebba4d]">฿120</span>
                  <button className="bg-[#ebba4d] hover:bg-[#d9a93c] text-white p-2 rounded-full shadow-md">
                    <ShoppingCart className="h-5 w-5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Product 2 */}
            <div className="bg-[#eee4c9] rounded-lg overflow-hidden shadow-lg transition-transform duration-300 hover:transform hover:scale-105 elegant-card">
              <div className="relative h-64">
                <Image src="/images/brown-rice.jpg" alt="ข้าวกล้อง" fill className="object-cover" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-serif font-bold mb-2 tracking-wide">ข้าวกล้อง</h3>
                <p className="text-gray-700 mb-4 text-elegant">ข้าวกล้องคุณภาพดี อุดมไปด้วยคุณค่าทางโภชนาการ</p>
                <div className="flex justify-between items-center">
                  <span className="text-xl font-bold text-[#ebba4d]">฿150</span>
                  <button className="bg-[#ebba4d] hover:bg-[#d9a93c] text-white p-2 rounded-full shadow-md">
                    <ShoppingCart className="h-5 w-5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Product 3 */}
            <div className="bg-[#eee4c9] rounded-lg overflow-hidden shadow-lg transition-transform duration-300 hover:transform hover:scale-105 elegant-card">
              <div className="relative h-64">
                <Image src="/images/riceberry.jpg" alt="ข้าวไรซ์เบอร์รี่" fill className="object-cover" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-serif font-bold mb-2 tracking-wide">ข้าวไรซ์เบอร์รี่</h3>
                <p className="text-gray-700 mb-4 text-elegant">ข้าวไรซ์เบอร์รี่ มีสารต้านอนุมูลอิสระสูง ดีต่อสุขภาพ</p>
                <div className="flex justify-between items-center">
                  <span className="text-xl font-bold text-[#ebba4d]">฿180</span>
                  <button className="bg-[#ebba4d] hover:bg-[#d9a93c] text-white p-2 rounded-full shadow-md">
                    <ShoppingCart className="h-5 w-5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Product 4 */}
            <div className="bg-[#eee4c9] rounded-lg overflow-hidden shadow-lg transition-transform duration-300 hover:transform hover:scale-105 elegant-card">
              <div className="relative h-64">
                <Image src="/images/dried-banana.jpg" alt="กล้วยตาก" fill className="object-cover" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-serif font-bold mb-2 tracking-wide">กล้วยตาก</h3>
                <p className="text-gray-700 mb-4 text-elegant">กล้วยตากหวานอร่อย ทำจากกล้วยน้ำว้าคุณภาพดี</p>
                <div className="flex justify-between items-center">
                  <span className="text-xl font-bold text-[#ebba4d]">฿80</span>
                  <button className="bg-[#ebba4d] hover:bg-[#d9a93c] text-white p-2 rounded-full shadow-md">
                    <ShoppingCart className="h-5 w-5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 bg-[#ebba4d]">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-8 md:mb-0">
              <div className="relative h-80 w-full md:w-5/6 mx-auto rounded-lg overflow-hidden shadow-xl">
                <Image src="/images/rice-farm.jpg" alt="ฟาร์มข้าวของเรา" fill className="object-cover" />
              </div>
            </div>
            <div className="md:w-1/2">
              <div className="flex justify-center md:justify-start mb-6">
                <Logo size="medium" textColor="white" />
              </div>
              <h2 className="text-3xl font-serif font-bold mb-6 text-white tracking-wide text-shadow-elegant">
                เกี่ยวกับร้าน "ปู่กะย่า"
              </h2>
              <p className="text-white text-lg mb-6 leading-relaxed tracking-wide">
                ร้านปู่กะย่าก่อตั้งขึ้นด้วยความตั้งใจที่จะนำเสนอข้าวคุณภาพดีจากไร่ของครอบครัวเรา เราปลูกข้าวด้วยความใส่ใจในทุกขั้นตอน
                ตั้งแต่การเพาะปลูกไปจนถึงการเก็บเกี่ยวและการบรรจุ
              </p>
              <p className="text-white text-lg leading-relaxed tracking-wide">
                ด้วยประสบการณ์กว่า 30 ปีในการทำนา เราภูมิใจที่จะนำเสนอข้าวคุณภาพดีที่สุดให้กับลูกค้าของเรา
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How to Order */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-serif font-bold text-center mb-12 text-[#ebba4d] tracking-wide">วิธีการสั่งซื้อ</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-[#eee4c9] p-8 rounded-lg text-center shadow-lg elegant-card">
              <div className="w-20 h-20 bg-[#ebba4d] rounded-full flex items-center justify-center mx-auto mb-6 shadow-md">
                <span className="text-white text-2xl font-bold">1</span>
              </div>
              <h3 className="text-xl font-serif font-bold mb-4 tracking-wide">เลือกสินค้า</h3>
              <p className="text-elegant">เลือกสินค้าที่ต้องการและใส่ในตะกร้าสินค้า</p>
            </div>

            <div className="bg-[#eee4c9] p-8 rounded-lg text-center shadow-lg elegant-card">
              <div className="w-20 h-20 bg-[#ebba4d] rounded-full flex items-center justify-center mx-auto mb-6 shadow-md">
                <span className="text-white text-2xl font-bold">2</span>
              </div>
              <h3 className="text-xl font-serif font-bold mb-4 tracking-wide">กรอกข้อมูล</h3>
              <p className="text-elegant">กรอกข้อมูลการจัดส่งและเลือกวิธีการชำระเงิน</p>
            </div>

            <div className="bg-[#eee4c9] p-8 rounded-lg text-center shadow-lg elegant-card">
              <div className="w-20 h-20 bg-[#ebba4d] rounded-full flex items-center justify-center mx-auto mb-6 shadow-md">
                <span className="text-white text-2xl font-bold">3</span>
              </div>
              <h3 className="text-xl font-serif font-bold mb-4 tracking-wide">รอรับสินค้า</h3>
              <p className="text-elegant">เราจะจัดส่งสินค้าให้คุณภายใน 1-3 วันทำการ</p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-[#eee4c9]">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-serif font-bold text-center mb-12 text-[#ebba4d] tracking-wide">ช่องทางติดต่อ</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-lg text-center elegant-card">
              <Phone className="w-12 h-12 text-[#ebba4d] mx-auto mb-4" />
              <h3 className="text-xl font-serif font-bold mb-4 tracking-wide">โทรศัพท์</h3>
              <p className="text-elegant">099-999-9999</p>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-lg text-center elegant-card">
              <Mail className="w-12 h-12 text-[#ebba4d] mx-auto mb-4" />
              <h3 className="text-xl font-serif font-bold mb-4 tracking-wide">อีเมล</h3>
              <p className="text-elegant">contact@pookaya.com</p>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-lg text-center elegant-card">
              <MapPin className="w-12 h-12 text-[#ebba4d] mx-auto mb-4" />
              <h3 className="text-xl font-serif font-bold mb-4 tracking-wide">ที่อยู่</h3>
              <p className="text-elegant">123 หมู่ 4 ต.บ้านนา อ.เมือง จ.นครราชสีมา 30000</p>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
