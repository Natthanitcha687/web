import Image from "next/image"
import Link from "next/link"
import { CreditCard, Landmark, QrCode, Truck, Clock, MapPin } from "lucide-react"

export default function HowToOrderPage() {
  return (
    <main className="min-h-screen bg-[#eee4c9] py-16">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold text-center mb-12 text-[#ebba4d]">วิธีการสั่งซื้อ</h1>

        {/* Steps */}
        <div className="max-w-5xl mx-auto bg-white rounded-lg shadow-lg p-8 mb-12">
          <div className="space-y-16">
            {/* Step 1 */}
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="md:w-1/2">
                <div className="relative h-80 w-full rounded-lg overflow-hidden shadow-md">
                  <Image
                    src="/images/step1-select-product.png"
                    alt="เลือกสินค้า"
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 100vw, 50vw"
                  />
                </div>
              </div>
              <div className="md:w-1/2">
                <div className="flex items-center mb-4">
                  <div className="w-14 h-14 bg-[#ebba4d] rounded-full flex items-center justify-center mr-4 shadow-md">
                    <span className="text-white text-2xl font-bold">1</span>
                  </div>
                  <h2 className="text-2xl font-bold text-[#ebba4d]">เลือกสินค้า</h2>
                </div>
                <p className="text-gray-700 text-lg leading-relaxed">
                  เลือกสินค้าที่คุณต้องการจากหน้า "สินค้าของเรา" และคลิกที่ไอคอนตะกร้าเพื่อเพิ่มสินค้าลงในตะกร้า
                  คุณสามารถเลือกสินค้าได้หลายรายการและปรับจำนวนได้ตามต้องการ เรามีข้าวหลากหลายชนิดให้คุณเลือก ทั้งข้าวหอมมะลิ ข้าวกล้อง
                  และข้าวไรซ์เบอร์รี่
                </p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="md:w-1/2 md:order-last">
                <div className="relative h-80 w-full rounded-lg overflow-hidden shadow-md">
                  <Image
                    src="/images/step2-checkout.png"
                    alt="กรอกข้อมูล"
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 100vw, 50vw"
                  />
                </div>
              </div>
              <div className="md:w-1/2">
                <div className="flex items-center mb-4">
                  <div className="w-14 h-14 bg-[#ebba4d] rounded-full flex items-center justify-center mr-4 shadow-md">
                    <span className="text-white text-2xl font-bold">2</span>
                  </div>
                  <h2 className="text-2xl font-bold text-[#ebba4d]">กรอกข้อมูล</h2>
                </div>
                <p className="text-gray-700 text-lg leading-relaxed">
                  เมื่อคุณเลือกสินค้าเรียบร้อยแล้ว คลิกที่ไอคอนตะกร้าที่มุมขวาบนของหน้าเว็บไซต์เพื่อดูรายการสินค้าที่เลือก จากนั้นคลิกปุ่ม
                  "ดำเนินการสั่งซื้อ" และกรอกข้อมูลการจัดส่งให้ครบถ้วน ทั้งชื่อ-นามสกุล ที่อยู่ เบอร์โทรศัพท์ และอีเมล
                  เพื่อให้เราสามารถจัดส่งสินค้าให้คุณได้อย่างถูกต้อง
                </p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="md:w-1/2">
                <div className="relative h-80 w-full rounded-lg overflow-hidden shadow-md">
                  <Image
                    src="/images/step3-payment.png"
                    alt="ชำระเงิน"
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 100vw, 50vw"
                  />
                </div>
              </div>
              <div className="md:w-1/2">
                <div className="flex items-center mb-4">
                  <div className="w-14 h-14 bg-[#ebba4d] rounded-full flex items-center justify-center mr-4 shadow-md">
                    <span className="text-white text-2xl font-bold">3</span>
                  </div>
                  <h2 className="text-2xl font-bold text-[#ebba4d]">ชำระเงิน</h2>
                </div>
                <p className="text-gray-700 text-lg leading-relaxed">
                  เลือกวิธีการชำระเงินที่คุณสะดวก เรารองรับการชำระเงินหลายรูปแบบ ได้แก่ โอนเงินผ่านธนาคาร บัตรเครดิต/เดบิต และ QR Payment
                  เมื่อชำระเงินเรียบร้อยแล้ว ระบบจะส่งอีเมลยืนยันการสั่งซื้อให้คุณทันที
                  พร้อมรายละเอียดการสั่งซื้อและหมายเลขคำสั่งซื้อสำหรับติดตามสถานะ
                </p>
              </div>
            </div>

            {/* Step 4 */}
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="md:w-1/2 md:order-last">
                <div className="relative h-80 w-full rounded-lg overflow-hidden shadow-md">
                  <Image
                    src="/images/step4-delivery.png"
                    alt="รอรับสินค้า"
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 100vw, 50vw"
                  />
                </div>
              </div>
              <div className="md:w-1/2">
                <div className="flex items-center mb-4">
                  <div className="w-14 h-14 bg-[#ebba4d] rounded-full flex items-center justify-center mr-4 shadow-md">
                    <span className="text-white text-2xl font-bold">4</span>
                  </div>
                  <h2 className="text-2xl font-bold text-[#ebba4d]">รอรับสินค้า</h2>
                </div>
                <p className="text-gray-700 text-lg leading-relaxed">
                  เราจะจัดส่งสินค้าให้คุณภายใน 1-3 วันทำการ (ขึ้นอยู่กับพื้นที่จัดส่ง)
                  คุณสามารถติดตามสถานะการจัดส่งได้ผ่านทางอีเมลหรือเบอร์โทรศัพท์ที่คุณให้ไว้ เมื่อได้รับสินค้าแล้ว
                  โปรดตรวจสอบความเรียบร้อยของสินค้าทันที และหากมีปัญหาใดๆ สามารถติดต่อเราได้ทันที
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Payment Methods */}
        <div className="max-w-5xl mx-auto bg-white rounded-lg shadow-lg p-8 mb-12">
          <h2 className="text-3xl font-bold mb-8 text-[#ebba4d] text-center">วิธีการชำระเงิน</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Bank Transfer */}
            <div className="bg-[#eee4c9] rounded-lg overflow-hidden shadow-md">
              <div className="relative h-48 w-full">
                <Image
                  src="/images/payment-bank.png"
                  alt="โอนเงินผ่านธนาคาร"
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 100vw, 33vw"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <Landmark className="w-6 h-6 text-[#ebba4d] mr-2" />
                  <h3 className="text-xl font-bold">โอนเงินผ่านธนาคาร</h3>
                </div>
                <p className="text-gray-700 mb-4">โอนเงินเข้าบัญชีของเราได้ตามรายละเอียดด้านล่าง:</p>
                <ul className="list-disc list-inside text-gray-700 ml-4 space-y-2">
                  <li>ธนาคารกสิกรไทย: 123-4-56789-0</li>
                  <li>ชื่อบัญชี: บริษัท ปู่กะย่า จำกัด</li>
                  <li>สาขา: สยามสแควร์</li>
                </ul>
              </div>
            </div>

            {/* Credit Card */}
            <div className="bg-[#eee4c9] rounded-lg overflow-hidden shadow-md">
              <div className="relative h-48 w-full">
                <Image
                  src="/images/payment-credit-card.png"
                  alt="บัตรเครดิต/เดบิต"
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 100vw, 33vw"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <CreditCard className="w-6 h-6 text-[#ebba4d] mr-2" />
                  <h3 className="text-xl font-bold">บัตรเครดิต/เดบิต</h3>
                </div>
                <p className="text-gray-700">
                  เรารองรับการชำระเงินผ่านบัตรเครดิตและเดบิตทุกธนาคาร ข้อมูลบัตรของคุณจะได้รับการเข้ารหัสและปลอดภัย รองรับบัตร Visa,
                  MasterCard, JCB และ American Express
                </p>
              </div>
            </div>

            {/* QR Payment */}
            <div className="bg-[#eee4c9] rounded-lg overflow-hidden shadow-md">
              <div className="relative h-48 w-full">
                <Image
                  src="/images/payment-qr.png"
                  alt="QR Payment"
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 100vw, 33vw"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <QrCode className="w-6 h-6 text-[#ebba4d] mr-2" />
                  <h3 className="text-xl font-bold">QR Payment</h3>
                </div>
                <p className="text-gray-700">
                  สแกน QR Code เพื่อชำระเงินผ่านแอปพลิเคชันธนาคารหรือแอปพลิเคชันการชำระเงินอื่นๆ ได้อย่างสะดวกรวดเร็ว รองรับ PromptPay,
                  TrueMoney Wallet และ Mobile Banking ทุกธนาคาร
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Shipping Info */}
        <div className="max-w-5xl mx-auto bg-white rounded-lg shadow-lg p-8 mb-12">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="md:w-1/2">
              <h2 className="text-3xl font-bold mb-6 text-[#ebba4d]">ข้อมูลการจัดส่ง</h2>

              <div className="space-y-8">
                <div className="flex items-start">
                  <Truck className="w-6 h-6 text-[#ebba4d] mr-4 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="text-xl font-bold mb-2">ค่าจัดส่ง</h3>
                    <ul className="list-disc list-inside text-gray-700 ml-4 space-y-2">
                      <li>กรุงเทพฯ และปริมณฑล: 50 บาท</li>
                      <li>ต่างจังหวัด: 80 บาท</li>
                      <li>ฟรีค่าจัดส่งเมื่อสั่งซื้อครบ 1,000 บาทขึ้นไป</li>
                    </ul>
                  </div>
                </div>

                <div className="flex items-start">
                  <Clock className="w-6 h-6 text-[#ebba4d] mr-4 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="text-xl font-bold mb-2">ระยะเวลาการจัดส่ง</h3>
                    <ul className="list-disc list-inside text-gray-700 ml-4 space-y-2">
                      <li>กรุงเทพฯ และปริมณฑล: 1-2 วันทำการ</li>
                      <li>ต่างจังหวัด: 2-3 วันทำการ</li>
                      <li>พื้นที่ห่างไกล: 3-5 วันทำการ</li>
                    </ul>
                  </div>
                </div>

                <div className="flex items-start">
                  <MapPin className="w-6 h-6 text-[#ebba4d] mr-4 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="text-xl font-bold mb-2">บริษัทขนส่ง</h3>
                    <p className="text-gray-700 ml-4">
                      เราใช้บริการขนส่งจาก Kerry Express, Thailand Post และ Flash Express ขึ้นอยู่กับพื้นที่จัดส่งและความเหมาะสม
                      คุณสามารถติดตามพัสดุได้ผ่านหมายเลขพัสดุที่เราจะส่งให้ทางอีเมล
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="md:w-1/2">
              <div className="relative h-96 w-full rounded-lg overflow-hidden shadow-md">
                <Image
                  src="/images/shipping-info.png"
                  alt="ข้อมูลการจัดส่ง"
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 100vw, 50vw"
                />
              </div>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="text-center mt-12">
          <Link
            href="/products"
            className="bg-[#ebba4d] hover:bg-[#d9a93c] text-white font-bold py-4 px-10 rounded-full transition duration-300 inline-block text-lg shadow-md"
          >
            เริ่มช้อปปิ้งเลย
          </Link>
        </div>
      </div>
    </main>
  )
}
