"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"

export default function ProfilePage() {
  const { user, isLoading, updateProfile } = useAuth()
  const router = useRouter()
  const { toast } = useToast()

  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [phone, setPhone] = useState("")
  const [address, setAddress] = useState("")
  const [isUpdating, setIsUpdating] = useState(false)

  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/login")
    }

    if (user) {
      setName(user.name || "")
      setEmail(user.email || "")
      setPhone(user.phone || "")
      setAddress(user.address || "")
    }
  }, [user, isLoading, router])

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsUpdating(true)

    try {
      const success = await updateProfile({
        name,
        phone,
        address,
      })

      if (success) {
        toast({
          title: "อัปเดตโปรไฟล์สำเร็จ",
          description: "ข้อมูลของคุณได้รับการอัปเดตเรียบร้อยแล้ว",
          variant: "default",
        })
      } else {
        toast({
          title: "อัปเดตโปรไฟล์ไม่สำเร็จ",
          description: "ไม่สามารถอัปเดตข้อมูลของคุณได้ กรุณาลองใหม่อีกครั้ง",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: "ไม่สามารถอัปเดตข้อมูลได้ในขณะนี้ กรุณาลองใหม่ภายหลัง",
        variant: "destructive",
      })
    } finally {
      setIsUpdating(false)
    }
  }

  if (isLoading || !user) {
    return (
      <main className="min-h-screen bg-[#eee4c9] py-16">
        <div className="container mx-auto px-4">
          <div className="text-center">กำลังโหลด...</div>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-[#eee4c9] py-16">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold text-center mb-12 text-[#ebba4d]">โปรไฟล์ของฉัน</h1>

        <div className="max-w-4xl mx-auto">
          <Tabs defaultValue="profile" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="profile">ข้อมูลส่วนตัว</TabsTrigger>
              <TabsTrigger value="orders">ประวัติการสั่งซื้อ</TabsTrigger>
            </TabsList>

            <TabsContent value="profile">
              <Card>
                <CardHeader>
                  <CardTitle className="text-2xl text-[#ebba4d]">ข้อมูลส่วนตัว</CardTitle>
                  <CardDescription>จัดการข้อมูลส่วนตัวของคุณ</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleUpdateProfile} className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="name">ชื่อ-นามสกุล</Label>
                      <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email">อีเมล</Label>
                      <Input id="email" value={email} disabled className="bg-gray-100" />
                      <p className="text-xs text-gray-500">ไม่สามารถเปลี่ยนอีเมลได้</p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="phone">เบอร์โทรศัพท์</Label>
                      <Input
                        id="phone"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="กรอกเบอร์โทรศัพท์ของคุณ"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="address">ที่อยู่</Label>
                      <Textarea
                        id="address"
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        placeholder="กรอกที่อยู่ของคุณ"
                        rows={4}
                      />
                    </div>

                    <Button type="submit" className="w-full bg-[#ebba4d] hover:bg-[#d9a93c]" disabled={isUpdating}>
                      {isUpdating ? "กำลังอัปเดต..." : "บันทึกข้อมูล"}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="orders">
              <Card>
                <CardHeader>
                  <CardTitle className="text-2xl text-[#ebba4d]">ประวัติการสั่งซื้อ</CardTitle>
                  <CardDescription>ดูประวัติการสั่งซื้อทั้งหมดของคุณ</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8 text-gray-500">
                    <p>คุณยังไม่มีประวัติการสั่งซื้อ</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </main>
  )
}
