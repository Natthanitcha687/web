import Image from "next/image"
import { ShoppingCart } from "lucide-react"

export default function ProductsPage() {
  return (
    <main className="min-h-screen bg-[#eee4c9] py-16">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold text-center mb-12 text-[#ebba4d]">สินค้าของเรา</h1>

        {/* Product Categories */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          <button className="bg-[#ebba4d] text-white px-6 py-2 rounded-full">ทั้งหมด</button>
          <button className="bg-white text-[#ebba4d] hover:bg-[#ebba4d] hover:text-white px-6 py-2 rounded-full transition duration-300">
            ข้าว
          </button>
          <button className="bg-white text-[#ebba4d] hover:bg-[#ebba4d] hover:text-white px-6 py-2 rounded-full transition duration-300">
            ขนม
          </button>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Product 1 */}
          <div className="bg-white rounded-lg overflow-hidden shadow-lg transition-transform duration-300 hover:transform hover:scale-105">
            <div className="relative h-64">
              <Image src="/images/jasmine-rice.jpg" alt="ข้าวหอมมะลิ" fill className="object-cover" />
            </div>
            <div className="p-6">
              <h3 className="text-xl font-bold mb-2">ข้าวหอมมะลิ</h3>
              <p className="text-gray-700 mb-4">ข้าวหอมมะลิคุณภาพดี หอมนุ่ม รสชาติดีเยี่ยม</p>
              <div className="flex justify-between items-center">
                <span className="text-xl font-bold text-[#ebba4d]">฿120</span>
                <button className="bg-[#ebba4d] hover:bg-[#d9a93c] text-white p-2 rounded-full">
                  <ShoppingCart className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Product 2 */}
          <div className="bg-white rounded-lg overflow-hidden shadow-lg transition-transform duration-300 hover:transform hover:scale-105">
            <div className="relative h-64">
              <Image src="/images/jasmine-rice-5kg.jpg" alt="ข้าวหอมมะลิ 5 กก." fill className="object-cover" />
            </div>
            <div className="p-6">
              <h3 className="text-xl font-bold mb-2">ข้าวหอมมะลิ 5 กก.</h3>
              <p className="text-gray-700 mb-4">ข้าวหอมมะลิบรรจุถุง 5 กิโลกรัม คุณภาพดี</p>
              <div className="flex justify-between items-center">
                <span className="text-xl font-bold text-[#ebba4d]">฿550</span>
                <button className="bg-[#ebba4d] hover:bg-[#d9a93c] text-white p-2 rounded-full">
                  <ShoppingCart className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Product 3 */}
          <div className="bg-white rounded-lg overflow-hidden shadow-lg transition-transform duration-300 hover:transform hover:scale-105">
            <div className="relative h-64">
              <Image src="/images/brown-rice.jpg" alt="ข้าวกล้อง" fill className="object-cover" />
            </div>
            <div className="p-6">
              <h3 className="text-xl font-bold mb-2">ข้าวกล้อง</h3>
              <p className="text-gray-700 mb-4">ข้าวกล้องคุณภาพดี อุดมไปด้วยคุณค่าทางโภชนาการ</p>
              <div className="flex justify-between items-center">
                <span className="text-xl font-bold text-[#ebba4d]">฿150</span>
                <button className="bg-[#ebba4d] hover:bg-[#d9a93c] text-white p-2 rounded-full">
                  <ShoppingCart className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Product 4 */}
          <div className="bg-white rounded-lg overflow-hidden shadow-lg transition-transform duration-300 hover:transform hover:scale-105">
            <div className="relative h-64">
              <Image src="/images/brown-rice-5kg.jpg" alt="ข้าวกล้อง 5 กก." fill className="object-cover" />
            </div>
            <div className="p-6">
              <h3 className="text-xl font-bold mb-2">ข้าวกล้อง 5 กก.</h3>
              <p className="text-gray-700 mb-4">ข้าวกล้องบรรจุถุง 5 กิโลกรัม คุณภาพดี</p>
              <div className="flex justify-between items-center">
                <span className="text-xl font-bold text-[#ebba4d]">฿700</span>
                <button className="bg-[#ebba4d] hover:bg-[#d9a93c] text-white p-2 rounded-full">
                  <ShoppingCart className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Product 5 */}
          <div className="bg-white rounded-lg overflow-hidden shadow-lg transition-transform duration-300 hover:transform hover:scale-105">
            <div className="relative h-64">
              <Image src="/images/riceberry.jpg" alt="ข้าวไรซ์เบอร์รี่" fill className="object-cover" />
            </div>
            <div className="p-6">
              <h3 className="text-xl font-bold mb-2">ข้าวไรซ์เบอร์รี่</h3>
              <p className="text-gray-700 mb-4">ข้าวไรซ์เบอร์รี่ มีสารต้านอนุมูลอิสระสูง ดีต่อสุขภาพ</p>
              <div className="flex justify-between items-center">
                <span className="text-xl font-bold text-[#ebba4d]">฿180</span>
                <button className="bg-[#ebba4d] hover:bg-[#d9a93c] text-white p-2 rounded-full">
                  <ShoppingCart className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Product 6 */}
          <div className="bg-white rounded-lg overflow-hidden shadow-lg transition-transform duration-300 hover:transform hover:scale-105">
            <div className="relative h-64">
              <Image src="/images/riceberry-5kg.jpg" alt="ข้าวไรซ์เบอร์รี่ 5 กก." fill className="object-cover" />
            </div>
            <div className="p-6">
              <h3 className="text-xl font-bold mb-2">ข้าวไรซ์เบอร์รี่ 5 กก.</h3>
              <p className="text-gray-700 mb-4">ข้าวไรซ์เบอร์รี่บรรจุถุง 5 กิโลกรัม คุณภาพดี</p>
              <div className="flex justify-between items-center">
                <span className="text-xl font-bold text-[#ebba4d]">฿850</span>
                <button className="bg-[#ebba4d] hover:bg-[#d9a93c] text-white p-2 rounded-full">
                  <ShoppingCart className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Product 7 */}
          <div className="bg-white rounded-lg overflow-hidden shadow-lg transition-transform duration-300 hover:transform hover:scale-105">
            <div className="relative h-64">
              <Image src="/images/dried-banana.jpg" alt="กล้วยตาก" fill className="object-cover" />
            </div>
            <div className="p-6">
              <h3 className="text-xl font-bold mb-2">กล้วยตาก</h3>
              <p className="text-gray-700 mb-4">กล้วยตากหวานอร่อย ทำจากกล้วยน้ำว้าคุณภาพดี</p>
              <div className="flex justify-between items-center">
                <span className="text-xl font-bold text-[#ebba4d]">฿80</span>
                <button className="bg-[#ebba4d] hover:bg-[#d9a93c] text-white p-2 rounded-full">
                  <ShoppingCart className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Product 8 */}
          <div className="bg-white rounded-lg overflow-hidden shadow-lg transition-transform duration-300 hover:transform hover:scale-105">
            <div className="relative h-64">
              <Image src="/images/dried-banana-pack.jpg" alt="กล้วยตากแพ็ค 5 ชิ้น" fill className="object-cover" />
            </div>
            <div className="p-6">
              <h3 className="text-xl font-bold mb-2">กล้วยตากแพ็ค 5 ชิ้น</h3>
              <p className="text-gray-700 mb-4">กล้วยตากบรรจุแพ็ค 5 ชิ้น สะดวกสำหรับการพกพา</p>
              <div className="flex justify-between items-center">
                <span className="text-xl font-bold text-[#ebba4d]">฿350</span>
                <button className="bg-[#ebba4d] hover:bg-[#d9a93c] text-white p-2 rounded-full">
                  <ShoppingCart className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
