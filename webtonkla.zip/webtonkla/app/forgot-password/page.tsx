"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // จำลองการส่งอีเมลรีเซ็ตรหัสผ่าน
    try {
      // ในสถานการณ์จริง คุณจะส่งคำขอไปยัง API เพื่อส่งอีเมลรีเซ็ตรหัสผ่าน
      await new Promise((resolve) => setTimeout(resolve, 1500))

      setIsSubmitted(true)
      toast({
        title: "ส่งอีเมลสำเร็จ",
        description: "กรุณาตรวจสอบอีเมลของคุณเพื่อรีเซ็ตรหัสผ่าน",
        variant: "default",
      })
    } catch (error) {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: "ไม่สามารถส่งอีเมลรีเซ็ตรหัสผ่านได้ กรุณาลองใหม่ภายหลัง",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <main className="min-h-screen bg-[#eee4c9] py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-md mx-auto">
          <Card>
            <CardHeader className="space-y-1">
              <CardTitle className="text-2xl font-bold text-center text-[#ebba4d]">ลืมรหัสผ่าน</CardTitle>
              <CardDescription className="text-center">กรอกอีเมลของคุณเพื่อรีเซ็ตรหัสผ่าน</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {!isSubmitted ? (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">อีเมล</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="your@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>
                  <Button type="submit" className="w-full bg-[#ebba4d] hover:bg-[#d9a93c]" disabled={isSubmitting}>
                    {isSubmitting ? "กำลังส่ง..." : "ส่งลิงก์รีเซ็ตรหัสผ่าน"}
                  </Button>
                </form>
              ) : (
                <div className="text-center py-4">
                  <p className="mb-4">เราได้ส่งลิงก์สำหรับรีเซ็ตรหัสผ่านไปยังอีเมล {email} แล้ว</p>
                  <p className="text-sm text-gray-500">หากคุณไม่ได้รับอีเมล กรุณาตรวจสอบโฟลเดอร์สแปมหรือลองส่งอีกครั้ง</p>
                </div>
              )}
            </CardContent>
            <CardFooter className="flex justify-center">
              <Link href="/login" className="text-[#ebba4d] hover:underline text-sm">
                กลับไปยังหน้าเข้าสู่ระบบ
              </Link>
            </CardFooter>
          </Card>
        </div>
      </div>
    </main>
  )
}
