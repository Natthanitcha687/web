import { Phone, Mail, MapPin, Clock, Facebook, Instagram } from "lucide-react"

export default function ContactPage() {
  return (
    <main className="min-h-screen bg-[#eee4c9] py-16">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold text-center mb-12 text-[#ebba4d]">ช่องทางติดต่อ</h1>

        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Contact Info */}
            <div className="bg-white rounded-lg shadow-lg p-8">
              <h2 className="text-2xl font-bold mb-6 text-[#ebba4d]">ข้อมูลติดต่อ</h2>

              <div className="space-y-6">
                <div className="flex items-start">
                  <Phone className="w-6 h-6 text-[#ebba4d] mr-4 flex-shrink-0" />
                  <div>
                    <h3 className="text-lg font-bold mb-1">โทรศัพท์</h3>
                    <p className="text-gray-700">099-999-9999</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <Mail className="w-6 h-6 text-[#ebba4d] mr-4 flex-shrink-0" />
                  <div>
                    <h3 className="text-lg font-bold mb-1">อีเมล</h3>
                    <p className="text-gray-700">contact@pookaya.com</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <MapPin className="w-6 h-6 text-[#ebba4d] mr-4 flex-shrink-0" />
                  <div>
                    <h3 className="text-lg font-bold mb-1">ที่อยู่</h3>
                    <p className="text-gray-700">123 หมู่ 4 ต.บ้านนา อ.เมือง จ.นครราชสีมา 30000</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <Clock className="w-6 h-6 text-[#ebba4d] mr-4 flex-shrink-0" />
                  <div>
                    <h3 className="text-lg font-bold mb-1">เวลาทำการ</h3>
                    <p className="text-gray-700">
                      วันจันทร์ - วันศุกร์: 08:30 - 17:30 น.
                      <br />
                      วันเสาร์: 09:00 - 15:00 น.
                      <br />
                      วันอาทิตย์: ปิดทำการ
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-8">
                <h3 className="text-lg font-bold mb-4">ติดตามเราได้ที่</h3>
                <div className="flex space-x-4">
                  <a
                    href="https://facebook.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-[#eee4c9] hover:bg-[#ebba4d] text-[#ebba4d] hover:text-white p-3 rounded-full transition duration-300"
                  >
                    <Facebook className="h-6 w-6" />
                  </a>
                  <a
                    href="https://instagram.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-[#eee4c9] hover:bg-[#ebba4d] text-[#ebba4d] hover:text-white p-3 rounded-full transition duration-300"
                  >
                    <Instagram className="h-6 w-6" />
                  </a>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="bg-white rounded-lg shadow-lg p-8">
              <h2 className="text-2xl font-bold mb-6 text-[#ebba4d]">ส่งข้อความถึงเรา</h2>

              <form>
                <div className="mb-4">
                  <label htmlFor="name" className="block text-gray-700 font-medium mb-2">
                    ชื่อ-นามสกุล
                  </label>
                  <input
                    type="text"
                    id="name"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#ebba4d]"
                    placeholder="กรุณากรอกชื่อ-นามสกุล"
                    required
                  />
                </div>

                <div className="mb-4">
                  <label htmlFor="email" className="block text-gray-700 font-medium mb-2">
                    อีเมล
                  </label>
                  <input
                    type="email"
                    id="email"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#ebba4d]"
                    placeholder="กรุณากรอกอีเมล"
                    required
                  />
                </div>

                <div className="mb-4">
                  <label htmlFor="phone" className="block text-gray-700 font-medium mb-2">
                    เบอร์โทรศัพท์
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#ebba4d]"
                    placeholder="กรุณากรอกเบอร์โทรศัพท์"
                  />
                </div>

                <div className="mb-4">
                  <label htmlFor="subject" className="block text-gray-700 font-medium mb-2">
                    หัวข้อ
                  </label>
                  <input
                    type="text"
                    id="subject"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#ebba4d]"
                    placeholder="กรุณากรอกหัวข้อ"
                    required
                  />
                </div>

                <div className="mb-6">
                  <label htmlFor="message" className="block text-gray-700 font-medium mb-2">
                    ข้อความ
                  </label>
                  <textarea
                    id="message"
                    rows={5}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#ebba4d]"
                    placeholder="กรุณากรอกข้อความ"
                    required
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#ebba4d] hover:bg-[#d9a93c] text-white font-bold py-3 px-6 rounded-lg transition duration-300"
                >
                  ส่งข้อความ
                </button>
              </form>
            </div>
          </div>

          {/* Map */}
          <div className="mt-12 bg-white rounded-lg shadow-lg p-8">
            <h2 className="text-2xl font-bold mb-6 text-[#ebba4d]">แผนที่</h2>
            <div className="h-96 bg-gray-200 rounded-lg">
              {/* ในที่นี้คุณสามารถใส่ iframe ของ Google Maps ได้ */}
              <div className="w-full h-full flex items-center justify-center">
                <p className="text-gray-500">แผนที่จะแสดงที่นี่</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
