import Link from "next/link"
import { Facebook, Instagram, Phone, Mail } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-[#ebba4d] text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* About */}
          <div>
            <h3 className="text-xl font-bold mb-4">เกี่ยวกับเรา</h3>
            <p className="mb-4">ร้านข้าวปู่กะย่า จำหน่ายข้าวคุณภาพดีจากไร่ของครอบครัวเรา มุ่งมั่นที่จะส่งมอบผลิตภัณฑ์ที่มีคุณภาพสูงสุดให้กับลูกค้า</p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-bold mb-4">ลิงก์ด่วน</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="hover:underline">
                  หน้าแรก
                </Link>
              </li>
              <li>
                <Link href="/products" className="hover:underline">
                  สินค้าของเรา
                </Link>
              </li>
              <li>
                <Link href="/how-to-order" className="hover:underline">
                  วิธีการสั่งซื้อ
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:underline">
                  ช่องทางติดต่อ
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-xl font-bold mb-4">ติดต่อเรา</h3>
            <ul className="space-y-2">
              <li className="flex items-center">
                <Phone className="h-5 w-5 mr-2" />
                <span>099-999-9999</span>
              </li>
              <li className="flex items-center">
                <Mail className="h-5 w-5 mr-2" />
                <span>contact@pookaya.com</span>
              </li>
            </ul>
          </div>

          {/* Social Media */}
          <div>
            <h3 className="text-xl font-bold mb-4">ติดตามเรา</h3>
            <div className="flex space-x-4">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-[#eee4c9] transition duration-300"
              >
                <Facebook className="h-6 w-6" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-[#eee4c9] transition duration-300"
              >
                <Instagram className="h-6 w-6" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-white/20 mt-8 pt-8 text-center">
          <p>&copy; {new Date().getFullYear()} ร้านข้าวปู่กะย่า. สงวนลิขสิทธิ์ทั้งหมด.</p>
        </div>
      </div>
    </footer>
  )
}
